# Teensy 4.1 Dual CAN-FD + LIN/K R9 final candidate

Use the R9 FAB_READY package generated from:

- `teensy-41-dual-canfd-lin-r9-final-candidate.kicad_pcb`

This is the current manufacturing prototype candidate for first-run PCB fabrication and bench testing. It uses OBD2 pigtail pads plus DIP switches, not a board-mounted OBD connector.

Open `R9_FAB_READY_STATUS.md` and the package-root `README_STATUS.txt` before ordering.
